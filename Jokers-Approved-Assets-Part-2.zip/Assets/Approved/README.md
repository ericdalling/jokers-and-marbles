# Approved Jokers and Marbles visual assets

Extract at repository root. Models/master-piece.glb is the modular geometry reference; Models/premium-marble-board.glb is the final material reference. Earlier approved assembly models are retained for comparison. UI contains approved layouts; Animation contains the movement prototype. Materials and References contain supporting assets, not separate final UI approvals.

Current requirements override illustrative mockup state: Host Mode terminology, automatic QR connection, 1–6 humans with bots filling to three, corrected entry positions, stationary board, five private cards and automatic replacement. See docs/design/approved-production-baseline.md in the repository. Geometry and device performance still require validation. The separately approved onboarding storyboard is not included because its exact filename could not be confidently identified.
